package com.example.budgetapp

import android.content.Context

/**
 * Utility class for applying settings to the app
 */
class SettingsUtils(private val context: Context) {
    private val preferencesManager = PreferencesManager(context)

    /**
     * Formats currency value according to user preferences
     */
    fun formatCurrency(amount: Double): String {
        val symbol = preferencesManager.getCurrencySymbol()
        return if (preferencesManager.getShowCents()) {
            "$symbol${"%.2f".format(amount)}"
        } else {
            "$symbol${amount.toInt()}"
        }
    }

    /**
     * Checks if the app should use dark mode
     */
    fun shouldUseDarkMode(): Boolean {
        return preferencesManager.getDarkMode()
    }

    /**
     * Gets alert threshold percentage
     */
    fun getBudgetAlertThreshold(): Int {
        return preferencesManager.getBudgetAlertThreshold()
    }

    /**
     * Checks if budget alerts are enabled
     */
    fun areNotificationsEnabled(): Boolean {
        return preferencesManager.getNotificationsEnabled()
    }
}