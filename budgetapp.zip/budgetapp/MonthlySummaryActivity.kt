package com.example.budgetapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.tabs.TabLayout
import java.text.SimpleDateFormat
import java.util.*

class MonthlySummaryActivity : AppCompatActivity() {
    private lateinit var monthYearText: TextView
    private lateinit var previousMonthButton: ImageButton
    private lateinit var nextMonthButton: ImageButton
    private lateinit var monthlyIncome: TextView
    private lateinit var monthlyExpenses: TextView
    private lateinit var monthlyBalance: TextView
    private lateinit var tabLayout: TabLayout
    private lateinit var categorySummaryList: RecyclerView
    private lateinit var bottomNavigation: BottomNavigationView

    private val calendar = Calendar.getInstance()
    private var currentType = "Income" // Default to Income tab

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthly_summary)

        // Initialize views
        monthYearText = findViewById(R.id.monthYearText)
        previousMonthButton = findViewById(R.id.previousMonthButton)
        nextMonthButton = findViewById(R.id.nextMonthButton)
        monthlyIncome = findViewById(R.id.monthlyIncome)
        monthlyExpenses = findViewById(R.id.monthlyExpenses)
        monthlyBalance = findViewById(R.id.monthlyBalance)
        tabLayout = findViewById(R.id.tabLayout)
        categorySummaryList = findViewById(R.id.categorySummaryList)
        bottomNavigation = findViewById(R.id.bottomNavigation)

        // Setup RecyclerView
        categorySummaryList.layoutManager = LinearLayoutManager(this)

        // Set month navigation
        previousMonthButton.setOnClickListener {
            calendar.add(Calendar.MONTH, -1)
            updateMonthView()
        }

        nextMonthButton.setOnClickListener {
            calendar.add(Calendar.MONTH, 1)
            updateMonthView()
        }

        // Setup tab listener
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (tab?.position == 0) {
                    currentType = "Income"
                } else {
                    currentType = "Expense"
                }
                updateCategoryList()
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        // Setup bottom navigation
        setupBottomNavigation()

        // Initial update
        updateMonthView()
    }

    private fun setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    // Navigate to home
                    finish()
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }

                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }

    }


    private fun updateMonthView() {
        // Update month header
        val dateFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        monthYearText.text = dateFormat.format(calendar.time)

        // Update summary data
        updateSummaryData()

        // Update category list
        updateCategoryList()
    }



    private fun updateSummaryData() {
        val transactions = getMonthTransactions()

        val income = transactions.filter { it.type == "Income" }.sumOf { it.amount }
        val expenses = transactions.filter { it.type == "Expense" }.sumOf { it.amount }
        val balance = income - expenses

        monthlyIncome.text = "LKR ${"%.2f".format(income)}"
        monthlyExpenses.text = "LKR ${"%.2f".format(expenses)}"
        monthlyBalance.text = "LKR ${"%.2f".format(balance)}"
    }

    private fun updateCategoryList() {
        val transactions = getMonthTransactions().filter { it.type == currentType }

        // Group by category and calculate totals
        val categoryMap = mutableMapOf<String, Double>()

        transactions.forEach { transaction ->
            val currentAmount = categoryMap[transaction.category] ?: 0.0
            categoryMap[transaction.category] = currentAmount + transaction.amount
        }

        // Calculate total for percentages
        val total = transactions.sumOf { it.amount }

        // Convert to list for adapter
        val categorySummaries = categoryMap.map { entry ->
            CategorySummary(
                name = entry.key,
                amount = entry.value,
                percentage = if (total > 0) (entry.value / total * 100) else 0.0
            )
        }.sortedByDescending { it.amount }

        // Update adapter
        categorySummaryList.adapter = CategorySummaryAdapter(categorySummaries)
    }

    private fun getMonthTransactions(): List<Transaction> {
        val allTransactions = TransactionManager.getAllTransactions(this)
        val firstDay = getFirstDayOfMonth()
        val lastDay = getLastDayOfMonth()

        return allTransactions.filter { transaction ->
            try {
                val transactionDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).parse(transaction.date)
                transactionDate in firstDay..lastDay
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun getFirstDayOfMonth(): Date {
        val cal = calendar.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.time
    }

    private fun getLastDayOfMonth(): Date {
        val cal = calendar.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.HOUR_OF_DAY, 23)
        cal.set(Calendar.MINUTE, 59)
        cal.set(Calendar.SECOND, 59)
        cal.set(Calendar.MILLISECOND, 999)
        return cal.time
    }

    data class CategorySummary(
        val name: String,
        val amount: Double,
        val percentage: Double
    )

    private inner class CategorySummaryAdapter(private val categories: List<CategorySummary>) :
        RecyclerView.Adapter<CategorySummaryAdapter.ViewHolder>() {

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val icon: ImageView = itemView.findViewById(R.id.categoryIcon)
            val name: TextView = itemView.findViewById(R.id.categoryName)
            val amount: TextView = itemView.findViewById(R.id.categoryAmount)
            val percentage: TextView = itemView.findViewById(R.id.categoryPercentage)
            val progress: ProgressBar = itemView.findViewById(R.id.categoryProgress)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_category_summary, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val category = categories[position]

            holder.name.text = category.name
            holder.amount.text = "LKR ${"%.2f".format(category.amount)}"
            holder.percentage.text = "${"%.1f".format(category.percentage)}%"

            // Set progress bar
            holder.progress.max = 100
            holder.progress.progress = category.percentage.toInt()

            // Set icon and colors based on type
            if (currentType == "Income") {
                holder.icon.setImageResource(R.drawable.ic_income)
                holder.amount.setTextColor(ContextCompat.getColor(this@MonthlySummaryActivity, R.color.green))
            } else {
                holder.icon.setImageResource(R.drawable.ic_expense)
                holder.amount.setTextColor(ContextCompat.getColor(this@MonthlySummaryActivity, R.color.red))
            }
        }

        override fun getItemCount() = categories.size
    }
}
