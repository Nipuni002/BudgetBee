package com.example.budgetapp

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        PREFERENCES_NAME, Context.MODE_PRIVATE
    )

    // Currency preferences
    fun setCurrencySymbol(symbol: String) {
        sharedPreferences.edit().putString(KEY_CURRENCY_SYMBOL, symbol).apply()
    }

    fun getCurrencySymbol(): String {
        return sharedPreferences.getString(KEY_CURRENCY_SYMBOL, DEFAULT_CURRENCY_SYMBOL) ?: DEFAULT_CURRENCY_SYMBOL
    }

    // Budget limits preferences
    fun setBudgetLimit(category: String, limit: Double) {
        sharedPreferences.edit().putFloat("$KEY_BUDGET_LIMIT_PREFIX$category", limit.toFloat()).apply()
    }

    fun getBudgetLimit(category: String): Double {
        return sharedPreferences.getFloat("$KEY_BUDGET_LIMIT_PREFIX$category", 0f).toDouble()
    }

    fun getAllBudgetLimits(): Map<String, Double> {
        val result = mutableMapOf<String, Double>()
        val allPrefs = sharedPreferences.all

        for ((key, value) in allPrefs) {
            if (key.startsWith(KEY_BUDGET_LIMIT_PREFIX) && value is Float) {
                val category = key.removePrefix(KEY_BUDGET_LIMIT_PREFIX)
                result[category] = value.toDouble()
            }
        }

        return result
    }

    // Display preferences
    fun setShowCents(showCents: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_SHOW_CENTS, showCents).apply()
    }

    fun getShowCents(): Boolean {
        return sharedPreferences.getBoolean(KEY_SHOW_CENTS, DEFAULT_SHOW_CENTS)
    }

    fun setDarkMode(darkMode: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_DARK_MODE, darkMode).apply()
    }

    fun getDarkMode(): Boolean {
        return sharedPreferences.getBoolean(KEY_DARK_MODE, DEFAULT_DARK_MODE)
    }

    // Notification preferences
    fun setNotificationsEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean(KEY_NOTIFICATIONS_ENABLED, enabled).apply()
    }

    fun getNotificationsEnabled(): Boolean {
        return sharedPreferences.getBoolean(KEY_NOTIFICATIONS_ENABLED, DEFAULT_NOTIFICATIONS_ENABLED)
    }

    fun setBudgetAlertThreshold(threshold: Int) {
        sharedPreferences.edit().putInt(KEY_BUDGET_ALERT_THRESHOLD, threshold).apply()
    }

    fun getBudgetAlertThreshold(): Int {
        return sharedPreferences.getInt(KEY_BUDGET_ALERT_THRESHOLD, DEFAULT_BUDGET_ALERT_THRESHOLD)
    }

    companion object {
        private const val PREFERENCES_NAME = "BudgetAppPreferences"

        // Keys
        private const val KEY_CURRENCY_SYMBOL = "currency_symbol"
        private const val KEY_BUDGET_LIMIT_PREFIX = "budget_limit_"
        private const val KEY_SHOW_CENTS = "show_cents"
        private const val KEY_DARK_MODE = "dark_mode"
        private const val KEY_NOTIFICATIONS_ENABLED = "notifications_enabled"
        private const val KEY_BUDGET_ALERT_THRESHOLD = "budget_alert_threshold"

        // Defaults
        private const val DEFAULT_CURRENCY_SYMBOL = "$"
        private const val DEFAULT_SHOW_CENTS = true
        private const val DEFAULT_DARK_MODE = false
        private const val DEFAULT_NOTIFICATIONS_ENABLED = true
        private const val DEFAULT_BUDGET_ALERT_THRESHOLD = 80  // 80% of budget
    }
}