package com.example.budgetapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class BalanceActivity : AppCompatActivity() {
    private lateinit var totalIncome: TextView
    private lateinit var totalExpenses: TextView
    private lateinit var currentBalance: TextView
    private lateinit var balanceDate: TextView
    private lateinit var addIncomeButton: Button
    private lateinit var addExpenseButton: Button
    private lateinit var monthlySummaryButton: Button
    private lateinit var recentTransactionsList: RecyclerView
    private lateinit var viewAllTransactions: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_balance)

        // Initialize views
        totalIncome = findViewById(R.id.totalIncome)
        totalExpenses = findViewById(R.id.totalExpenses)
        currentBalance = findViewById(R.id.currentBalance)
        balanceDate = findViewById(R.id.balanceDate)
        addIncomeButton = findViewById(R.id.addIncomeButton)
        addExpenseButton = findViewById(R.id.addExpenseButton)
        monthlySummaryButton = findViewById(R.id.monthlySummaryButton)
        recentTransactionsList = findViewById(R.id.recentTransactionsList)
        viewAllTransactions = findViewById(R.id.viewAllTransactions)

        // Set current date in balance card
        val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
        balanceDate.text = "As of ${dateFormat.format(Date())}"

        // Setup RecyclerView
        recentTransactionsList.layoutManager = LinearLayoutManager(this)
        recentTransactionsList.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )

        // Set click listeners
        addIncomeButton.setOnClickListener {
            startActivity(Intent(this, InputIncomeActivity::class.java))
        }

        addExpenseButton.setOnClickListener {
            startActivity(Intent(this, InputExpenseActivity::class.java))
        }

        monthlySummaryButton.setOnClickListener {
            startActivity(Intent(this, MonthlySummaryActivity::class.java))
        }

        // Hide "View All" text since we're now showing all transactions
        viewAllTransactions.visibility = View.GONE

        findViewById<BottomNavigationView>(R.id.bottomNavigation).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    // Already on home screen
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }
                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        updateBalance()
    }

    private fun updateBalance() {
        val transactions = TransactionManager.getAllTransactions(this)

        // Calculate totals
        val income = transactions.filter { it.type == "Income" }.sumOf { it.amount }
        val expenses = transactions.filter { it.type == "Expense" }.sumOf { it.amount }
        val balance = income - expenses

        // Update balance views
        totalIncome.text = "LKR ${"%.2f".format(income)}"
        totalExpenses.text = "LKR ${"%.2f".format(expenses)}"
        currentBalance.text = "LKR ${"%.2f".format(balance)}"

        // Update transactions list to show all transactions sorted by date (newest first)
        val allTransactions = transactions.sortedByDescending { it.date }
        recentTransactionsList.adapter = TransactionAdapter(allTransactions)
    }

    private inner class TransactionAdapter(private val transactions: List<Transaction>) :
        RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder>() {

        inner class TransactionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val icon: ImageView = itemView.findViewById(R.id.transactionIcon)
            val title: TextView = itemView.findViewById(R.id.transactionTitle)
            val category: TextView = itemView.findViewById(R.id.transactionCategory)
            val amount: TextView = itemView.findViewById(R.id.transactionAmount)
            val date: TextView = itemView.findViewById(R.id.transactionDate)
            val editButton: ImageButton = itemView.findViewById(R.id.editButton)
            val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransactionViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_transaction, parent, false)
            return TransactionViewHolder(view)
        }

        override fun onBindViewHolder(holder: TransactionViewHolder, position: Int) {
            val transaction = transactions[position]

            holder.title.text = transaction.title
            holder.category.text = transaction.category
            holder.date.text = transaction.date

            if (transaction.type == "Income") {
                holder.amount.text = "+LKR ${"%.2f".format(transaction.amount)}"
                holder.amount.setTextColor(ContextCompat.getColor(this@BalanceActivity, R.color.green))
                holder.icon.setImageResource(R.drawable.ic_income)
            } else {
                holder.amount.text = "-LKR ${"%.2f".format(transaction.amount)}"
                holder.amount.setTextColor(ContextCompat.getColor(this@BalanceActivity, R.color.red))
                holder.icon.setImageResource(R.drawable.ic_expense)
            }

            // Set edit button click listener
            holder.editButton.setOnClickListener {
                editTransaction(transaction)
            }

            // Set delete button click listener
            holder.deleteButton.setOnClickListener {
                showDeleteConfirmation(transaction)
            }
        }


        override fun getItemCount() = transactions.size
    }

    private fun editTransaction(transaction: Transaction) {
        // Create an Intent based on transaction type
        val intent = if (transaction.type == "Income") {
            Intent(this, InputIncomeActivity::class.java)
        } else {
            Intent(this, InputExpenseActivity::class.java)
        }

        // Pass the transaction data to the edit activity
        intent.putExtra("EDIT_MODE", true)
        intent.putExtra("TRANSACTION_TITLE", transaction.title)
        intent.putExtra("TRANSACTION_AMOUNT", transaction.amount)
        intent.putExtra("TRANSACTION_CATEGORY", transaction.category)
        intent.putExtra("TRANSACTION_DATE", transaction.date)
        intent.putExtra("TRANSACTION_INDEX", TransactionManager.getTransactionIndex(this, transaction))

        startActivity(intent)
    }

    private fun showDeleteConfirmation(transaction: Transaction) {
        AlertDialog.Builder(this)
            .setTitle("Delete Transaction")
            .setMessage("Are you sure you want to delete this transaction?")
            .setPositiveButton("Delete") { _, _ ->
                TransactionManager.deleteTransaction(this, transaction)
                Toast.makeText(this, "Transaction deleted", Toast.LENGTH_SHORT).show()
                updateBalance()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}