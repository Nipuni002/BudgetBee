package com.example.budgetapp

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject

class BudgetManager(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val notificationHelper = NotificationHelper(context)

    // Track notification status to avoid repeated notifications
    private val notificationStatus = mutableMapOf<String, Boolean>()

    // Set total budget for a specific month
    fun setTotalBudget(monthYearKey: String, amount: Double) {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        // Get or create month object
        val monthObj = if (budgetsJson.has(monthYearKey)) {
            budgetsJson.getJSONObject(monthYearKey)
        } else {
            JSONObject()
        }

        // Set total budget amount
        monthObj.put(TOTAL_BUDGET_KEY, amount)

        // Save back to budgets object
        budgetsJson.put(monthYearKey, monthObj)

        // Save to preferences
        prefs.edit().putString(BUDGETS_KEY, budgetsJson.toString()).apply()
    }

    // Get total budget for a specific month
    fun getTotalBudget(monthYearKey: String): Double {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        if (!budgetsJson.has(monthYearKey)) {
            return 0.0
        }

        val monthObj = budgetsJson.getJSONObject(monthYearKey)
        return monthObj.optDouble(TOTAL_BUDGET_KEY, 0.0)
    }

    // Set budget for a specific category in a specific month
    fun setCategoryBudget(monthYearKey: String, category: String, amount: Double) {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        // Get or create month object
        val monthObj = if (budgetsJson.has(monthYearKey)) {
            budgetsJson.getJSONObject(monthYearKey)
        } else {
            JSONObject()
        }

        // Get or create categories object
        val categoriesObj = if (monthObj.has(CATEGORIES_KEY)) {
            monthObj.getJSONObject(CATEGORIES_KEY)
        } else {
            JSONObject()
        }

        // Set category budget
        categoriesObj.put(category, amount)

        // Save back to month object
        monthObj.put(CATEGORIES_KEY, categoriesObj)

        // Save back to budgets object
        budgetsJson.put(monthYearKey, monthObj)

        // Save to preferences
        prefs.edit().putString(BUDGETS_KEY, budgetsJson.toString()).apply()
    }

    // Get all category budgets for a specific month
    fun getCategoryBudgets(monthYearKey: String): Map<String, Double> {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        if (!budgetsJson.has(monthYearKey)) {
            return emptyMap()
        }

        val monthObj = budgetsJson.getJSONObject(monthYearKey)
        if (!monthObj.has(CATEGORIES_KEY)) {
            return emptyMap()
        }

        val categoriesObj = monthObj.getJSONObject(CATEGORIES_KEY)
        val result = mutableMapOf<String, Double>()

        categoriesObj.keys().forEach { category ->
            result[category] = categoriesObj.getDouble(category)
        }

        return result
    }

    // Get budget for a specific category in a specific month
    fun getCategoryBudget(monthYearKey: String, category: String): Double {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        if (!budgetsJson.has(monthYearKey)) {
            return 0.0
        }

        val monthObj = budgetsJson.getJSONObject(monthYearKey)
        if (!monthObj.has(CATEGORIES_KEY)) {
            return 0.0
        }

        val categoriesObj = monthObj.getJSONObject(CATEGORIES_KEY)
        return categoriesObj.optDouble(category, 0.0)
    }

    // Delete budget for a specific category in a specific month
    fun deleteCategoryBudget(monthYearKey: String, category: String) {
        val budgetsJson = JSONObject(prefs.getString(BUDGETS_KEY, "{}") ?: "{}")

        if (!budgetsJson.has(monthYearKey)) {
            return
        }

        val monthObj = budgetsJson.getJSONObject(monthYearKey)
        if (!monthObj.has(CATEGORIES_KEY)) {
            return
        }

        val categoriesObj = monthObj.getJSONObject(CATEGORIES_KEY)
        if (categoriesObj.has(category)) {
            categoriesObj.remove(category)

            // Save back to month object
            monthObj.put(CATEGORIES_KEY, categoriesObj)

            // Save back to budgets object
            budgetsJson.put(monthYearKey, monthObj)

            // Save to preferences
            prefs.edit().putString(BUDGETS_KEY, budgetsJson.toString()).apply()
        }
    }

    // Check if spending is approaching or exceeding budget
    fun checkBudgetWarningStatus(monthYearKey: String, totalExpenses: Double): BudgetWarningStatus {
        val totalBudget = getTotalBudget(monthYearKey)

        if (totalBudget <= 0) {
            return BudgetWarningStatus.NO_WARNING
        }

        val ratio = totalExpenses / totalBudget
        return when {
            ratio >= 1.0 -> BudgetWarningStatus.EXCEEDED
            ratio >= 0.8 -> BudgetWarningStatus.APPROACHING
            else -> BudgetWarningStatus.NO_WARNING
        }
    }

    // Check if category spending is approaching or exceeding budget
    fun checkCategoryBudgetWarningStatus(monthYearKey: String, category: String, expenses: Double): BudgetWarningStatus {
        val budget = getCategoryBudget(monthYearKey, category)

        if (budget <= 0) {
            return BudgetWarningStatus.NO_WARNING
        }

        val ratio = expenses / budget
        return when {
            ratio >= 1.0 -> BudgetWarningStatus.EXCEEDED
            ratio >= 0.8 -> BudgetWarningStatus.APPROACHING
            else -> BudgetWarningStatus.NO_WARNING
        }
    }

    // Check and notify about budget status
    fun checkAndNotifyBudgetStatus(monthYearKey: String) {
        // Check overall budget status
        checkAndNotifyOverallBudget(monthYearKey)

        // Check category budget status
        checkAndNotifyCategoryBudgets(monthYearKey)
    }

    private fun checkAndNotifyOverallBudget(monthYearKey: String) {
        val totalBudget = getTotalBudget(monthYearKey)
        if (totalBudget <= 0) return

        // Get month start and end dates
        val calendar = java.util.Calendar.getInstance()
        val sdf = java.text.SimpleDateFormat("MM-yyyy", java.util.Locale.getDefault())
        val date = sdf.parse(monthYearKey) ?: return
        calendar.time = date

        calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val startDate = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(calendar.time)

        calendar.set(java.util.Calendar.DAY_OF_MONTH, calendar.getActualMaximum(java.util.Calendar.DAY_OF_MONTH))
        val endDate = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(calendar.time)

        // Get total expenses
        val transactions = TransactionManager.getTransactionsBetweenDates(context, startDate, endDate)
        val totalExpenses = transactions.filter { it.type == "Expense" }.sumOf { it.amount }

        // Check status and notify if needed
        val status = checkBudgetWarningStatus(monthYearKey, totalExpenses)
        val notificationKey = "overall_$monthYearKey"

        if (status == BudgetWarningStatus.EXCEEDED && notificationStatus[notificationKey] != true) {
            notificationHelper.showBudgetWarningNotification(
                "Budget Alert",
                "You've exceeded your total monthly budget!"
            )
            notificationStatus[notificationKey] = true
        } else if (status == BudgetWarningStatus.APPROACHING && notificationStatus[notificationKey] != true) {
            notificationHelper.showBudgetWarningNotification(
                "Budget Alert",
                "You're approaching your total monthly budget limit (80% used)"
            )
            notificationStatus[notificationKey] = true
        }
    }

    private fun checkAndNotifyCategoryBudgets(monthYearKey: String) {
        val categoryBudgets = getCategoryBudgets(monthYearKey)
        if (categoryBudgets.isEmpty()) return

        // Get month start and end dates
        val calendar = java.util.Calendar.getInstance()
        val sdf = java.text.SimpleDateFormat("MM-yyyy", java.util.Locale.getDefault())
        val date = sdf.parse(monthYearKey) ?: return
        calendar.time = date

        calendar.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val startDate = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(calendar.time)

        calendar.set(java.util.Calendar.DAY_OF_MONTH, calendar.getActualMaximum(java.util.Calendar.DAY_OF_MONTH))
        val endDate = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault()).format(calendar.time)

        // Get transactions
        val transactions = TransactionManager.getTransactionsBetweenDates(context, startDate, endDate)

        // Group expenses by category
        val categoryExpenses = transactions
            .filter { it.type == "Expense" }
            .groupBy { it.category }
            .mapValues { it.value.sumOf { transaction -> transaction.amount } }

        // Check each category budget
        categoryBudgets.forEach { (category, budget) ->
            val spent = categoryExpenses[category] ?: 0.0
            val status = checkCategoryBudgetWarningStatus(monthYearKey, category, spent)
            val notificationKey = "category_${category}_$monthYearKey"

            if (status == BudgetWarningStatus.EXCEEDED && notificationStatus[notificationKey] != true) {
                notificationHelper.showBudgetWarningNotification(
                    "Category Budget Alert",
                    "You've exceeded your budget for $category!"
                )
                notificationStatus[notificationKey] = true
            } else if (status == BudgetWarningStatus.APPROACHING && notificationStatus[notificationKey] != true) {
                notificationHelper.showBudgetWarningNotification(
                    "Category Budget Alert",
                    "You're approaching your budget limit for $category (80% used)"
                )
                notificationStatus[notificationKey] = true
            }
        }
    }

    // Reset notification status for a new month
    fun resetNotificationStatus(monthYearKey: String) {
        notificationStatus.keys.removeAll { it.endsWith(monthYearKey) }
    }

    companion object {
        private const val PREFS_NAME = "BudgetManagerPrefs"
        private const val BUDGETS_KEY = "budgets"
        private const val TOTAL_BUDGET_KEY = "totalBudget"
        private const val CATEGORIES_KEY = "categories"
    }

    enum class BudgetWarningStatus {
        NO_WARNING,
        APPROACHING,
        EXCEEDED
    }
}