package com.example.budgetapp

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.Spanned
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class InputExpenseActivity : AppCompatActivity() {
    private lateinit var expenseTitle: EditText
    private lateinit var expenseAmount: EditText
    private lateinit var expenseCategory: Spinner
    private lateinit var expenseDateButton: Button
    private lateinit var saveExpenseButton: Button
    private lateinit var bottomNavigation: BottomNavigationView

    private var selectedDate = Calendar.getInstance()
    private var isEditMode = false
    private var transactionIndex = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_expense)

        expenseTitle = findViewById(R.id.expenseTitle)
        expenseAmount = findViewById(R.id.expenseAmount)
        expenseCategory = findViewById(R.id.expenseCategory)
        expenseDateButton = findViewById(R.id.expenseDateButton)
        saveExpenseButton = findViewById(R.id.saveExpenseButton)
        bottomNavigation = findViewById(R.id.bottomNavigation)

        // Set up amount input filter to only allow numeric values and decimal point
        expenseAmount.filters = arrayOf(DecimalDigitsInputFilter())

        // Check if in edit mode
        isEditMode = intent.getBooleanExtra("EDIT_MODE", false)

        if (isEditMode) {
            // Get transaction data from intent
            val title = intent.getStringExtra("TRANSACTION_TITLE") ?: ""
            val amount = intent.getDoubleExtra("TRANSACTION_AMOUNT", 0.0)
            val category = intent.getStringExtra("TRANSACTION_CATEGORY") ?: ""
            val date = intent.getStringExtra("TRANSACTION_DATE") ?: ""
            transactionIndex = intent.getIntExtra("TRANSACTION_INDEX", -1)

            // Fill the form with transaction data
            expenseTitle.setText(title)
            expenseAmount.setText(amount.toString())

            // Set the category spinner
            val adapter = expenseCategory.adapter as ArrayAdapter<String>
            val position = findCategoryPosition(adapter, category)
            if (position >= 0) {
                expenseCategory.setSelection(position)
            }

            // Set the date
            try {
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                selectedDate.time = sdf.parse(date) ?: Date()
            } catch (e: Exception) {
                // Use current date if parse fails
            }

            // Update button text
            saveExpenseButton.text = "Update Expense"
        }

        // Set current date as default
        updateDateButtonText()

        expenseDateButton.setOnClickListener {
            showDatePicker()
        }

        saveExpenseButton.setOnClickListener {
            saveExpense()
        }

        // Set up bottom navigation
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    // Navigate to home
                    finish()
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }

                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }

    }

    private fun findCategoryPosition(adapter: ArrayAdapter<String>, category: String): Int {
        for (i in 0 until adapter.count) {
            if (adapter.getItem(i) == category) {
                return i
            }
        }
        return -1
    }

    private fun showDatePicker() {
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, day ->
                selectedDate.set(year, month, day)
                updateDateButtonText()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    private fun updateDateButtonText() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        expenseDateButton.text = dateFormat.format(selectedDate.time)
    }

    private fun saveExpense() {
        val title = expenseTitle.text.toString().trim()
        val amountStr = expenseAmount.text.toString().trim()
        val category = expenseCategory.selectedItem.toString()
        val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedDate.time)

        if (title.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        // Create transaction object
        val transaction = Transaction(
            title = title,
            amount = amount,
            category = category,
            date = date,
            type = "Expense"
        )

        if (isEditMode && transactionIndex >= 0) {
            // Update existing transaction
            TransactionManager.updateTransaction(this, transactionIndex, transaction)
            Toast.makeText(this, "Expense updated successfully", Toast.LENGTH_SHORT).show()
        } else {
            // Add new transaction
            TransactionManager.addTransaction(this, transaction)
            Toast.makeText(this, "Expense saved successfully", Toast.LENGTH_SHORT).show()
        }

        finish()
    }

    // Custom InputFilter to only allow numeric values and a single decimal point
    inner class DecimalDigitsInputFilter : InputFilter {
        override fun filter(
            source: CharSequence,
            start: Int,
            end: Int,
            dest: Spanned,
            dstart: Int,
            dend: Int
        ): CharSequence? {
            // Allow backspace/delete operations
            if (source.isEmpty()) {
                return null
            }

            val builder = StringBuilder(dest)
            builder.replace(dstart, dend, source.subSequence(start, end).toString())
            val resultString = builder.toString()

            // Check if the result is a valid decimal number
            if (!resultString.matches(Regex("^\\d*\\.?\\d*$"))) {
                return ""
            }

            // Check if we already have a decimal point and are trying to add another
            if (resultString.count { it == '.' } > 1) {
                return ""
            }

            return null // Accept the input
        }
    }
}