package com.example.budgetapp

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.SwitchCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class SettingsActivity : AppCompatActivity() {
    private lateinit var preferencesManager: PreferencesManager

    private lateinit var currencySymbolSpinner: Spinner
    private lateinit var showCentsSwitch: SwitchCompat
    private lateinit var darkModeSwitch: SwitchCompat
    private lateinit var notificationsEnabledSwitch: SwitchCompat
    private lateinit var budgetAlertThresholdEdit: EditText
    private lateinit var saveSettingsButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        preferencesManager = PreferencesManager(this)

        // Initialize UI components
        currencySymbolSpinner = findViewById(R.id.currencySymbolSpinner)
        showCentsSwitch = findViewById(R.id.showCentsSwitch)
        darkModeSwitch = findViewById(R.id.darkModeSwitch)
        notificationsEnabledSwitch = findViewById(R.id.notificationsEnabledSwitch)
        budgetAlertThresholdEdit = findViewById(R.id.budgetAlertThresholdEdit)
        saveSettingsButton = findViewById(R.id.saveSettingsButton)

        // Setup currency spinner
        setupCurrencySpinner()

        // Load current settings
        loadSettings()

        // Setup save button
        saveSettingsButton.setOnClickListener {
            saveSettings()
        }

        // Setup navigation
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        findViewById<BottomNavigationView>(R.id.bottomNavigation).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    startActivity(Intent(this, BalanceActivity::class.java))
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }
                R.id.nav_Settings -> {
                    // Already on settings screen
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // Set the active navigation item
        findViewById<BottomNavigationView>(R.id.bottomNavigation).selectedItemId = R.id.nav_Settings
    }

    private fun setupCurrencySpinner() {
        val currencySymbols = arrayOf("$", "LKR", "£", "¥", "₹", "₽", "₩", "₺", "₴", "₦")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, currencySymbols)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        currencySymbolSpinner.adapter = adapter

        // Set selected currency symbol
        val currentSymbol = preferencesManager.getCurrencySymbol()
        val position = currencySymbols.indexOf(currentSymbol)
        if (position >= 0) {
            currencySymbolSpinner.setSelection(position)
        }
    }

    private fun loadSettings() {
        // Load display preferences
        showCentsSwitch.isChecked = preferencesManager.getShowCents()
        darkModeSwitch.isChecked = preferencesManager.getDarkMode()

        // Load notification preferences
        notificationsEnabledSwitch.isChecked = preferencesManager.getNotificationsEnabled()
        budgetAlertThresholdEdit.setText(preferencesManager.getBudgetAlertThreshold().toString())
    }

    private fun saveSettings() {
        try {
            // Save currency settings
            val selectedCurrency = currencySymbolSpinner.selectedItem.toString()
            preferencesManager.setCurrencySymbol(selectedCurrency)

            // Save display settings
            preferencesManager.setShowCents(showCentsSwitch.isChecked)
            preferencesManager.setDarkMode(darkModeSwitch.isChecked)

            // Set dark mode
            if (darkModeSwitch.isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }

            // Save notification settings
            preferencesManager.setNotificationsEnabled(notificationsEnabledSwitch.isChecked)

            val alertThreshold = budgetAlertThresholdEdit.text.toString().toIntOrNull()
            if (alertThreshold != null && alertThreshold in 1..100) {
                preferencesManager.setBudgetAlertThreshold(alertThreshold)
            } else {
                Toast.makeText(this, "Please enter a valid threshold (1-100)", Toast.LENGTH_SHORT).show()
                return
            }

            Toast.makeText(this, "Settings saved successfully", Toast.LENGTH_SHORT).show()
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error saving settings: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}