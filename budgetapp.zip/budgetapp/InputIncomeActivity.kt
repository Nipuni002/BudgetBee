package com.example.budgetapp

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.InputFilter
import android.text.Spanned
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class InputIncomeActivity : AppCompatActivity() {
    private lateinit var incomeTitle: EditText
    private lateinit var incomeAmount: EditText
    private lateinit var incomeCategory: Spinner
    private lateinit var incomeDateButton: Button
    private lateinit var saveIncomeButton: Button
    private lateinit var bottomNavigation: BottomNavigationView

    private var selectedDate = Calendar.getInstance()
    private var isEditMode = false
    private var transactionIndex = -1

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_income)

        incomeTitle = findViewById(R.id.incomeTitle)
        incomeAmount = findViewById(R.id.incomeAmount)
        incomeCategory = findViewById(R.id.incomeCategory)
        incomeDateButton = findViewById(R.id.incomeDateButton)
        saveIncomeButton = findViewById(R.id.saveIncomeButton)
        bottomNavigation = findViewById(R.id.bottomNavigation)

        // Apply numeric validation filter to amount field
        incomeAmount.filters = arrayOf(DecimalDigitsInputFilter(10, 2))

        // Check if in edit mode
        isEditMode = intent.getBooleanExtra("EDIT_MODE", false)

        if (isEditMode) {
            // Get transaction data from intent
            val title = intent.getStringExtra("TRANSACTION_TITLE") ?: ""
            val amount = intent.getDoubleExtra("TRANSACTION_AMOUNT", 0.0)
            val category = intent.getStringExtra("TRANSACTION_CATEGORY") ?: ""
            val date = intent.getStringExtra("TRANSACTION_DATE") ?: ""
            transactionIndex = intent.getIntExtra("TRANSACTION_INDEX", -1)

            // Fill the form with transaction data
            incomeTitle.setText(title)
            incomeAmount.setText(amount.toString())

            // Set the category spinner
            val adapter = incomeCategory.adapter as ArrayAdapter<String>
            val position = findCategoryPosition(adapter, category)
            if (position >= 0) {
                incomeCategory.setSelection(position)
            }

            // Set the date
            try {
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                selectedDate.time = sdf.parse(date) ?: Date()
            } catch (e: Exception) {
                // Use current date if parse fails
            }

            // Update button text
            saveIncomeButton.text = "Update Income"
        }

        // Set current date as default
        updateDateButtonText()

        incomeDateButton.setOnClickListener {
            showDatePicker()
        }

        saveIncomeButton.setOnClickListener {
            saveIncome()
        }

        // Setup navigation
        setupBottomNavigation()
    }

    private fun findCategoryPosition(adapter: ArrayAdapter<String>, category: String): Int {
        for (i in 0 until adapter.count) {
            if (adapter.getItem(i) == category) {
                return i
            }
        }
        return -1
    }

    private fun showDatePicker() {
        val datePicker = DatePickerDialog(
            this,
            { _, year, month, day ->
                selectedDate.set(year, month, day)
                updateDateButtonText()
            },
            selectedDate.get(Calendar.YEAR),
            selectedDate.get(Calendar.MONTH),
            selectedDate.get(Calendar.DAY_OF_MONTH)
        )
        datePicker.show()
    }

    private fun updateDateButtonText() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        incomeDateButton.text = dateFormat.format(selectedDate.time)
    }

    private fun saveIncome() {
        val title = incomeTitle.text.toString().trim()
        val amountStr = incomeAmount.text.toString().trim()
        val category = incomeCategory.selectedItem.toString()
        val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(selectedDate.time)

        if (title.isEmpty() || amountStr.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val amount = amountStr.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        // Create transaction object
        val transaction = Transaction(
            title = title,
            amount = amount,
            category = category,
            date = date,
            type = "Income"
        )

        if (isEditMode && transactionIndex >= 0) {
            // Update existing transaction
            TransactionManager.updateTransaction(this, transactionIndex, transaction)
            Toast.makeText(this, "Income updated successfully", Toast.LENGTH_SHORT).show()
        } else {
            // Add new transaction
            TransactionManager.addTransaction(this, transaction)
            Toast.makeText(this, "Income saved successfully", Toast.LENGTH_SHORT).show()
        }

        finish()
    }

    private fun setupBottomNavigation() {
        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    // Navigate to home
                    finish()
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }
                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }
    }

    // Input filter class to allow only numeric and decimal input
    inner class DecimalDigitsInputFilter(private val digits: Int, private val decimalPoints: Int) : InputFilter {
        override fun filter(
            source: CharSequence,
            start: Int,
            end: Int,
            dest: Spanned,
            dstart: Int,
            dend: Int
        ): CharSequence? {
            var dotPos = -1
            val len = dest.length
            for (i in 0 until len) {
                val c = dest[i]
                if (c == '.') {
                    dotPos = i
                    break
                }
            }

            if (dotPos >= 0) {
                // If the text already contains a decimal point
                if (source.contains('.')) {
                    return ""  // Do not allow another decimal point
                }
                if (dend <= dotPos) {
                    // If editing before the decimal point, check digit limit
                    if ((dest.length - (dend - dstart) + (end - start)) > digits + 1) {
                        return ""
                    }
                } else {
                    // If editing after the decimal point, check decimal place limit
                    if ((dest.length - dotPos - (dend - dstart) + (end - start)) > decimalPoints + 1) {
                        return ""
                    }
                }
            } else {
                // If no decimal point yet
                if (source.contains('.')) {
                    // If adding a decimal point, check if it would exceed digit limit
                    if (dstart > digits) {
                        return ""
                    }
                } else {
                    // If not adding a decimal point, check if total length would exceed digit limit
                    if ((dest.length - (dend - dstart) + (end - start)) > digits) {
                        return ""
                    }
                }
            }

            // Allow only digits and decimal point
            for (i in start until end) {
                val c = source[i]
                if (!Character.isDigit(c) && c != '.') {
                    return ""  // Reject non-digit and non-decimal characters
                }
            }
            return null  // Accept the input
        }
    }
}