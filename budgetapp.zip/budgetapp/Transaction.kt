package com.example.budgetapp

data class Transaction(
    val title: String,
    val amount: Double,
    val category: String,
    val date: String,
    val type: String
) {
    // Helper function to determine if two transactions are the same
    fun isSameAs(other: Transaction): Boolean {
        return title == other.title &&
                amount == other.amount &&
                category == other.category &&
                date == other.date &&
                type == other.type
    }
}