package com.example.budgetapp

data class Budget(
    val category: String,
    val amount: Double,
    val isOverall: Boolean = false
) {
    fun isSameAs(other: Budget): Boolean {
        return category == other.category && isOverall == other.isOverall
    }
}