package com.example.budgetapp

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class BudgetLimitsActivity : AppCompatActivity() {
    private lateinit var totalBudgetInput: EditText
    private lateinit var saveTotalBudgetButton: Button
    private lateinit var totalBudgetProgressBar: ProgressBar
    private lateinit var spentText: TextView
    private lateinit var remainingText: TextView
    private lateinit var warningText: TextView
    private lateinit var currentMonthText: TextView
    private lateinit var addCategoryBudgetButton: Button
    private lateinit var categoryBudgetsList: RecyclerView

    private lateinit var budgetManager: BudgetManager
    private val currentMonth = Calendar.getInstance()

    // Add permission launcher
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            // Now we can send notifications
        } else {
            Toast.makeText(
                this,
                "Notification permission denied. You won't receive budget alerts.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_limits)

        // Initialize budget manager
        budgetManager = BudgetManager(this)

        // Initialize views
        totalBudgetInput = findViewById(R.id.totalBudgetInput)
        saveTotalBudgetButton = findViewById(R.id.saveTotalBudgetButton)
        totalBudgetProgressBar = findViewById(R.id.totalBudgetProgressBar)
        spentText = findViewById(R.id.spentText)
        remainingText = findViewById(R.id.remainingText)
        warningText = findViewById(R.id.warningText)
        currentMonthText = findViewById(R.id.currentMonthText)
        addCategoryBudgetButton = findViewById(R.id.addCategoryBudgetButton)
        categoryBudgetsList = findViewById(R.id.categoryBudgetsList)

        // Setup RecyclerView
        categoryBudgetsList.layoutManager = LinearLayoutManager(this)

        // Set current month
        val dateFormat = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        currentMonthText.text = dateFormat.format(currentMonth.time)

        // Set click listeners
        saveTotalBudgetButton.setOnClickListener {
            saveTotalBudget()
        }

        addCategoryBudgetButton.setOnClickListener {
            showCategoryBudgetDialog()
        }

        // Setup bottom navigation
        findViewById<BottomNavigationView>(R.id.bottomNavigation).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    finish()
                    true
                }
                R.id.nav_Budget -> {
                    // Already on budget screen
                    true
                }
                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    startActivity(Intent(this, BackupActivity::class.java))
                    true
                }
                else -> false
            }
        }

        // Check notification permission
        checkNotificationPermission()

        // Initialize with saved values
        updateUI()
    }

    private fun checkNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED -> {
                    // Permission is already granted
                }
                shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) -> {
                    // Explain why we need the permission
                    showNotificationPermissionRationale()
                }
                else -> {
                    // Request the permission
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
    }

    private fun showNotificationPermissionRationale() {
        AlertDialog.Builder(this)
            .setTitle("Notification Permission")
            .setMessage("We need notification permission to alert you when your budget is approaching its limit.")
            .setPositiveButton("Grant Permission") { _, _ ->
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
            .setNegativeButton("Not Now", null)
            .show()
    }

    private fun saveTotalBudget() {
        val budgetStr = totalBudgetInput.text.toString().trim()
        if (budgetStr.isEmpty()) {
            Toast.makeText(this, "Please enter a budget amount", Toast.LENGTH_SHORT).show()
            return
        }

        val budget = budgetStr.toDoubleOrNull()
        if (budget == null || budget <= 0) {
            Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
            return
        }

        // Get current month and year as key
        val monthYearKey = SimpleDateFormat("MM-yyyy", Locale.getDefault()).format(currentMonth.time)

        // Save total budget
        budgetManager.setTotalBudget(monthYearKey, budget)

        // Check budget status for notifications
        budgetManager.checkAndNotifyBudgetStatus(monthYearKey)

        // Clear input and update UI
        totalBudgetInput.text.clear()
        updateUI()

        Toast.makeText(this, "Budget saved successfully", Toast.LENGTH_SHORT).show()
    }

    private fun updateUI() {
        // Get current month and year as key
        val monthYearKey = SimpleDateFormat("MM-yyyy", Locale.getDefault()).format(currentMonth.time)

        // Get total budget for current month
        val totalBudget = budgetManager.getTotalBudget(monthYearKey)

        // Get month start and end dates
        val calendar = Calendar.getInstance()
        calendar.time = currentMonth.time
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val startDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(calendar.time)

        calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH))
        val endDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(calendar.time)

        // Get expenses for current month
        val transactions = TransactionManager.getTransactionsBetweenDates(this, startDate, endDate)
        val totalExpenses = transactions.filter { it.type == "Expense" }.sumOf { it.amount }

        // Calculate remaining budget and progress
        val remaining = totalBudget - totalExpenses
        val progress = if (totalBudget > 0) ((totalExpenses / totalBudget) * 100).toInt() else 0

        // Update UI elements
        spentText.text = "Spent: LKR ${"%.2f".format(totalExpenses)}"
        remainingText.text = "Remaining: LKR ${"%.2f".format(remaining)}"
        totalBudgetProgressBar.progress = progress

        // Show warning if approaching or exceeding budget
        if (totalBudget > 0) {
            if (totalExpenses >= totalBudget) {
                warningText.text = "Warning: You've exceeded your budget!"
                warningText.visibility = View.VISIBLE
                totalBudgetProgressBar.progressTintList =
                    ContextCompat.getColorStateList(this, R.color.red)
            } else if (totalExpenses >= totalBudget * 0.8) {
                warningText.text = "Warning: You're approaching your budget limit!"
                warningText.visibility = View.VISIBLE
                totalBudgetProgressBar.progressTintList =
                    ContextCompat.getColorStateList(this, R.color.orange)
            } else {
                warningText.visibility = View.GONE
                totalBudgetProgressBar.progressTintList =
                    ContextCompat.getColorStateList(this, R.color.emerald_green_dark)
            }
        } else {
            warningText.visibility = View.GONE
        }

        // Update category budgets list
        updateCategoryBudgetsList(monthYearKey, transactions)

        // Check budget status for notifications
        budgetManager.checkAndNotifyBudgetStatus(monthYearKey)
    }

    private fun updateCategoryBudgetsList(monthYearKey: String, transactions: List<Transaction>) {
        val categoryBudgets = budgetManager.getCategoryBudgets(monthYearKey)

        // Create map of category to spent amount
        val categoryExpenses = transactions
            .filter { it.type == "Expense" }
            .groupBy { it.category }
            .mapValues { it.value.sumOf { transaction -> transaction.amount } }

        // Create list for adapter
        val categoryBudgetItems = categoryBudgets.map { (category, budget) ->
            val spent = categoryExpenses[category] ?: 0.0
            CategoryBudgetItem(category, budget, spent)
        }

        categoryBudgetsList.adapter = CategoryBudgetAdapter(categoryBudgetItems)
    }

    private fun showCategoryBudgetDialog(existingCategory: String = "", existingAmount: Double = 0.0) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_category_budget, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        val dialogTitle = dialogView.findViewById<TextView>(R.id.dialogTitle)
        val categorySpinner = dialogView.findViewById<Spinner>(R.id.categorySpinner)
        val budgetAmountInput = dialogView.findViewById<EditText>(R.id.budgetAmountInput)
        val saveButton = dialogView.findViewById<Button>(R.id.saveButton)
        val cancelButton = dialogView.findViewById<Button>(R.id.cancelButton)

        // Set title based on whether we're adding or editing
        if (existingCategory.isNotEmpty()) {
            dialogTitle.text = "Edit Category Budget"
            budgetAmountInput.setText(existingAmount.toString())
        }

        // Populate spinner with expense categories
        val categories = resources.getStringArray(R.array.expense_categories)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        categorySpinner.adapter = adapter

        // Set selected category if editing
        if (existingCategory.isNotEmpty()) {
            val position = categories.indexOf(existingCategory)
            if (position >= 0) {
                categorySpinner.setSelection(position)
            }
            // Disable spinner if editing
            categorySpinner.isEnabled = false
        }

        saveButton.setOnClickListener {
            val category = categorySpinner.selectedItem.toString()
            val budgetStr = budgetAmountInput.text.toString().trim()

            if (budgetStr.isEmpty()) {
                Toast.makeText(this, "Please enter a budget amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val budget = budgetStr.toDoubleOrNull()
            if (budget == null || budget <= 0) {
                Toast.makeText(this, "Please enter a valid amount", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Get current month and year as key
            val monthYearKey = SimpleDateFormat("MM-yyyy", Locale.getDefault()).format(currentMonth.time)

            // Save category budget
            budgetManager.setCategoryBudget(monthYearKey, category, budget)

            // Check budget status for notifications
            budgetManager.checkAndNotifyBudgetStatus(monthYearKey)

            // Update UI and dismiss dialog
            updateUI()
            dialog.dismiss()

            Toast.makeText(this, "Category budget saved", Toast.LENGTH_SHORT).show()
        }

        cancelButton.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun showDeleteCategoryBudgetConfirmation(category: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete Category Budget")
            .setMessage("Are you sure you want to delete the budget for $category?")
            .setPositiveButton("Delete") { _, _ ->
                // Get current month and year as key
                val monthYearKey = SimpleDateFormat("MM-yyyy", Locale.getDefault()).format(currentMonth.time)

                // Delete category budget
                budgetManager.deleteCategoryBudget(monthYearKey, category)

                // Update UI
                updateUI()

                Toast.makeText(this, "Category budget deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private inner class CategoryBudgetAdapter(private val items: List<CategoryBudgetItem>) :
        RecyclerView.Adapter<CategoryBudgetAdapter.ViewHolder>() {

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val categoryName: TextView = itemView.findViewById(R.id.categoryName)
            val budgetAmount: TextView = itemView.findViewById(R.id.budgetAmount)
            val spentAmount: TextView = itemView.findViewById(R.id.spentAmount)
            val progressBar: ProgressBar = itemView.findViewById(R.id.categoryProgressBar)
            val warningText: TextView = itemView.findViewById(R.id.categoryWarningText)
            val editButton: ImageButton = itemView.findViewById(R.id.editCategoryButton)
            val deleteButton: ImageButton = itemView.findViewById(R.id.deleteCategoryButton)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_category_budget, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]

            holder.categoryName.text = item.category
            holder.budgetAmount.text = "Budget: LKR ${"%.2f".format(item.budget)}"
            holder.spentAmount.text = "Spent: LKR ${"%.2f".format(item.spent)}"

            // Calculate progress
            val progress = if (item.budget > 0) ((item.spent / item.budget) * 100).toInt() else 0
            holder.progressBar.progress = progress

            // Show warning if approaching or exceeding budget
            if (item.spent >= item.budget) {
                holder.warningText.text = "Warning: Exceeded budget!"
                holder.warningText.visibility = View.VISIBLE
                holder.progressBar.progressTintList =
                    ContextCompat.getColorStateList(this@BudgetLimitsActivity, R.color.red)
            } else if (item.spent >= item.budget * 0.8) {
                holder.warningText.text = "Warning: Approaching budget limit!"
                holder.warningText.visibility = View.VISIBLE
                holder.progressBar.progressTintList =
                    ContextCompat.getColorStateList(this@BudgetLimitsActivity, R.color.golden_yellow)
            } else {
                holder.warningText.visibility = View.GONE
                holder.progressBar.progressTintList =
                    ContextCompat.getColorStateList(this@BudgetLimitsActivity, R.color.emerald_green_dark)
            }

            // Set edit button click listener
            holder.editButton.setOnClickListener {
                showCategoryBudgetDialog(item.category, item.budget)
            }

            // Set delete button click listener
            holder.deleteButton.setOnClickListener {
                showDeleteCategoryBudgetConfirmation(item.category)
            }
        }
        override fun getItemCount() = items.size
    }

    data class CategoryBudgetItem(
        val category: String,
        val budget: Double,
        val spent: Double
    )
}