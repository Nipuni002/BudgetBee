package com.example.budgetapp

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class OnboardingActivity : AppCompatActivity() {
    private lateinit var viewPager: ViewPager2
    private lateinit var tabLayout: TabLayout
    private lateinit var nextButton: Button
    private lateinit var skipButton: TextView

    // Onboarding content
    private val onboardingItems = listOf(
        OnboardingItem(
            R.drawable.onboarding_track_income,
            "Track Your Finances",
            "Keep track of your income and expenses with ease, all in one place"
        ),
        OnboardingItem(
            R.drawable.onboarding_manage_expenses,
            "Set Budget Goals",
            "Create budget limits for different categories and stick to your financial goals"
        ),
        OnboardingItem(
            R.drawable.onboarding_set_budget,
            "Detailed Reports",
            "Get insights on your spending habits with monthly summaries and visualizations"
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        viewPager = findViewById(R.id.viewPager)
        tabLayout = findViewById(R.id.tabLayout)
        nextButton = findViewById(R.id.nextButton)
        skipButton = findViewById(R.id.skipButton)

        // Set up the ViewPager with the adapter
        val adapter = OnboardingAdapter(onboardingItems)
        viewPager.adapter = adapter

        // Connect the TabLayout with the ViewPager
        TabLayoutMediator(tabLayout, viewPager) { _, _ -> }.attach()

        nextButton.setOnClickListener {
            if (viewPager.currentItem < onboardingItems.size - 1) {
                viewPager.currentItem = viewPager.currentItem + 1
            } else {
                finishOnboarding()
            }
        }

        skipButton.setOnClickListener {
            finishOnboarding()
        }

        // Update button text when on the last page
        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                if (position == onboardingItems.size - 1) {
                    nextButton.text = "Get Started"
                } else {
                    nextButton.text = "Next"
                }

                // Show/hide skip button based on position
                skipButton.visibility = if (position == onboardingItems.size - 1) View.GONE else View.VISIBLE
            }
        })
    }

    private fun finishOnboarding() {
        // Mark first launch as complete
        val sharedPreferences = getSharedPreferences("BudgetBeePrefs", MODE_PRIVATE)
        sharedPreferences.edit().putBoolean("is_first_launch", false).apply()

        // Navigate to login screen
        startActivity(Intent(this, BalanceActivity::class.java))
        finish()
    }

    // Data class for onboarding items
    data class OnboardingItem(val imageRes: Int, val title: String, val description: String)

    // Adapter for the ViewPager
    inner class OnboardingAdapter(private val items: List<OnboardingItem>) :
        RecyclerView.Adapter<OnboardingAdapter.OnboardingViewHolder>() {

        inner class OnboardingViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            private val imageView: ImageView = view.findViewById(R.id.imageView)
            private val titleText: TextView = view.findViewById(R.id.titleText)
            private val descriptionText: TextView = view.findViewById(R.id.descriptionText)

            fun bind(item: OnboardingItem) {
                imageView.setImageResource(item.imageRes)
                titleText.text = item.title
                descriptionText.text = item.description
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OnboardingViewHolder {
            return OnboardingViewHolder(
                LayoutInflater.from(parent.context).inflate(R.layout.onboarding_page, parent, false)
            )
        }

        override fun onBindViewHolder(holder: OnboardingViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size
    }
}