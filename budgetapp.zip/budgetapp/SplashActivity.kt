package com.example.budgetapp

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Check if first launch
        val sharedPreferences = getSharedPreferences("BudgetBeePrefs", MODE_PRIVATE)
        val isFirstLaunch = sharedPreferences.getBoolean("is_first_launch", true)

        // Delay for 2 seconds then launch the appropriate screen
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFirstLaunch) {
                // First launch - show onboarding
                startActivity(Intent(this, OnboardingActivity::class.java))
            } else {
                // Not first launch - check if logged in
                val isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false)

                    // User is already logged in, go to main screen
                    startActivity(Intent(this, OnboardingActivity::class.java))

            }
            finish()
        }, 2000)
    }
}