package com.example.budgetapp

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.*

object TransactionManager {
    const val PREFS_NAME = "FinanceTrackerPrefs"
    const val TRANSACTIONS_KEY = "transactions"
    private const val DELIMITER = "|||"
    private const val ITEM_DELIMITER = ":::"

    fun addTransaction(context: Context, transaction: Transaction) {
        val transactions = getAllTransactions(context).toMutableList()
        transactions.add(transaction)
        saveTransactions(context, transactions)
    }

    fun updateTransaction(context: Context, index: Int, updatedTransaction: Transaction) {
        val transactions = getAllTransactions(context).toMutableList()
        if (index >= 0 && index < transactions.size) {
            transactions[index] = updatedTransaction
            saveTransactions(context, transactions)
        }
    }

    fun deleteTransaction(context: Context, transaction: Transaction) {
        val transactions = getAllTransactions(context).toMutableList()
        transactions.removeAll { it.isSameAs(transaction) }
        saveTransactions(context, transactions)
    }

    fun getTransactionIndex(context: Context, transaction: Transaction): Int {
        val transactions = getAllTransactions(context)
        return transactions.indexOfFirst { it.isSameAs(transaction) }
    }

    fun getAllTransactions(context: Context): List<Transaction> {
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val transactionsString = sharedPrefs.getString(TRANSACTIONS_KEY, "") ?: ""

        if (transactionsString.isEmpty()) return emptyList()

        return transactionsString.split(DELIMITER).mapNotNull { item ->
            if (item.isEmpty()) return@mapNotNull null
            val parts = item.split(ITEM_DELIMITER)
            if (parts.size != 5) return@mapNotNull null

            try {
                Transaction(
                    title = parts[0],
                    amount = parts[1].toDouble(),
                    category = parts[2],
                    date = parts[3],
                    type = parts[4]
                )
            } catch (e: Exception) {
                null
            }
        }
    }

    // Function to get transactions between two dates
    fun getTransactionsBetweenDates(
        context: Context,
        startDate: String,
        endDate: String
    ): List<Transaction> {
        val allTransactions = getAllTransactions(context)
        if (startDate.isEmpty() || endDate.isEmpty()) return allTransactions

        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val start = try {
            dateFormat.parse(startDate)?.time ?: 0L
        } catch (e: Exception) {
            0L
        }

        val end = try {
            dateFormat.parse(endDate)?.time ?: Long.MAX_VALUE
        } catch (e: Exception) {
            Long.MAX_VALUE
        }

        return allTransactions.filter {
            try {
                val transactionDate = dateFormat.parse(it.date)?.time ?: 0L
                transactionDate in start..end
            } catch (e: Exception) {
                false
            }
        }
    }

    fun saveTransactions(context: Context, transactions: List<Transaction>) {
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val editor = sharedPrefs.edit()

        val transactionsString = transactions.joinToString(DELIMITER) { transaction ->
            listOf(
                transaction.title,
                transaction.amount.toString(),
                transaction.category,
                transaction.date,
                transaction.type
            ).joinToString(ITEM_DELIMITER)
        }

        editor.putString(TRANSACTIONS_KEY, transactionsString)
        editor.apply()
    }

    // Clear all transactions (for restore functionality)
    fun clearAllTransactions(context: Context) {
        val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        sharedPrefs.edit().remove(TRANSACTIONS_KEY).apply()
    }
}