package com.example.budgetapp

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.RadioButton
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONArray
import org.json.JSONObject
import java.io.*
import java.text.SimpleDateFormat
import java.util.*

class BackupActivity : AppCompatActivity() {

    private lateinit var jsonFormat: RadioButton
    private lateinit var csvFormat: RadioButton
    private lateinit var backupButton: Button
    private lateinit var restoreButton: Button
    private lateinit var lastBackupText: TextView
    private lateinit var backupLocationText: TextView

    private val backupFolder = "BudgetApp"
    private val prefs by lazy { getSharedPreferences("BackupPrefs", MODE_PRIVATE) }

    // Register file creation result handler
    private val createDocument = registerForActivityResult(ActivityResultContracts.CreateDocument()) { uri ->
        uri?.let { exportDataToUri(it) }
    }

    // Register file open result handler
    private val openDocument = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { importDataFromUri(it) }
    }

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Check if all requested permissions were granted
        val allGranted = permissions.all { it.value }

        if (allGranted) {
            Toast.makeText(this, "Storage permissions granted", Toast.LENGTH_SHORT).show()
            // If the permission request was triggered by a specific action, continue with that action
            when (pendingAction) {
                PendingAction.BACKUP -> createBackup()
                PendingAction.RESTORE -> openRestoreFile()
                PendingAction.NONE -> { /* Do nothing */ }
            }
            pendingAction = PendingAction.NONE
        } else {
            Toast.makeText(this, "Storage permissions are needed for backup/restore", Toast.LENGTH_LONG).show()
        }
    }

    // Track what action is pending permission approval
    private enum class PendingAction { NONE, BACKUP, RESTORE }
    private var pendingAction = PendingAction.NONE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_backup)

        // Initialize views
        jsonFormat = findViewById(R.id.jsonFormat)
        csvFormat = findViewById(R.id.csvFormat)
        backupButton = findViewById(R.id.backupButton)
        restoreButton = findViewById(R.id.restoreButton)
        lastBackupText = findViewById(R.id.lastBackupText)
        backupLocationText = findViewById(R.id.backupLocationText)

        // Set backup location text
        val storageDir = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            "Internal Storage > Documents > BudgetApp"
        } else {
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS).absolutePath + "/BudgetApp"
        }
        backupLocationText.text = "Backup files will be saved to: $storageDir"

        // Update last backup text
        updateLastBackupText()

        // Set click listeners
        backupButton.setOnClickListener {
            checkPermissionsAndExecute(PendingAction.BACKUP)
        }

        restoreButton.setOnClickListener {
            checkPermissionsAndExecute(PendingAction.RESTORE)
        }

        // Bottom navigation setup
        findViewById<BottomNavigationView>(R.id.bottomNavigation).setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_Home -> {
                    startActivity(Intent(this, BalanceActivity::class.java))
                    true
                }
                R.id.nav_Budget -> {
                    startActivity(Intent(this, BudgetLimitsActivity::class.java))
                    true
                }
                R.id.nav_Settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                R.id.nav_Backup -> {
                    // Already on backup screen
                    true
                }
                else -> false
            }
        }
    }

    private fun checkPermissionsAndExecute(action: PendingAction) {
        pendingAction = action

        // For Android 13+ (API 33+), we don't need READ/WRITE_EXTERNAL_STORAGE permissions
        // since we're using Storage Access Framework
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            when {
                // Check if we have required permissions
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED &&
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        ) == PackageManager.PERMISSION_GRANTED -> {
                    // Execute the pending action
                    executePendingAction()
                }
                // Request the permissions
                else -> {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            }
        } else {
            // For Android 13+, just execute the action (SAF handles permissions)
            executePendingAction()
        }
    }

    private fun executePendingAction() {
        when (pendingAction) {
            PendingAction.BACKUP -> createBackup()
            PendingAction.RESTORE -> openRestoreFile()
            PendingAction.NONE -> { /* Do nothing */ }
        }
        pendingAction = PendingAction.NONE
    }

    private fun updateLastBackupText() {
        val lastBackup = prefs.getLong("lastBackupTime", 0)
        if (lastBackup > 0) {
            val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
            lastBackupText.text = "Last backup: ${dateFormat.format(Date(lastBackup))}"
        } else {
            lastBackupText.text = "Last backup: Never"
        }
    }

    private fun createBackup() {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = if (jsonFormat.isChecked) {
            "budget_backup_$timestamp.json"
        } else {
            "budget_backup_$timestamp.csv"
        }

        // Use Storage Access Framework to create document
        val mimeType = if (jsonFormat.isChecked) "application/json" else "text/csv"
        createDocument.launch(fileName)
    }

    private fun openRestoreFile() {
        // First show a warning dialog
        AlertDialog.Builder(this)
            .setTitle("Restore Backup")
            .setMessage("Restoring a backup will replace all current data. This action cannot be undone. Do you want to continue?")
            .setPositiveButton("Continue") { _, _ ->
                openDocument.launch(arrayOf("*/*"))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun exportDataToUri(uri: Uri) {
        try {
            val transactions = TransactionManager.getAllTransactions(this)

            contentResolver.openOutputStream(uri)?.use { outputStream ->
                val writer = BufferedWriter(OutputStreamWriter(outputStream))

                if (jsonFormat.isChecked) {
                    // Export as JSON
                    val jsonArray = JSONArray()
                    transactions.forEach { transaction ->
                        val jsonObject = JSONObject().apply {
                            put("title", transaction.title)
                            put("amount", transaction.amount)
                            put("category", transaction.category)
                            put("date", transaction.date)
                            put("type", transaction.type)
                        }
                        jsonArray.put(jsonObject)
                    }

                    writer.write(jsonArray.toString(4)) // Pretty print with indentation of 4
                } else {
                    // Export as CSV
                    writer.write("Title,Amount,Category,Date,Type\n")
                    transactions.forEach { transaction ->
                        // Escape values for CSV
                        val escapedTitle = escapeForCsv(transaction.title)
                        val escapedCategory = escapeForCsv(transaction.category)
                        writer.write("$escapedTitle,${transaction.amount},$escapedCategory,${transaction.date},${transaction.type}\n")
                    }
                }

                writer.flush()

                // Save last backup time
                prefs.edit()
                    .putLong("lastBackupTime", System.currentTimeMillis())
                    .apply()

                updateLastBackupText()
                Toast.makeText(this, "Backup created successfully", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error creating backup: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun escapeForCsv(value: String): String {
        // If the value contains commas, quotes, or newlines, wrap it in quotes and escape any quotes
        return if (value.contains(",") || value.contains("\"") || value.contains("\n")) {
            "\"${value.replace("\"", "\"\"")}\""
        } else {
            value
        }
    }

    private fun importDataFromUri(uri: Uri) {
        try {
            contentResolver.openInputStream(uri)?.use { inputStream ->
                val reader = BufferedReader(InputStreamReader(inputStream))
                val content = reader.readText()

                // Determine if JSON or CSV based on content
                if (content.trim().startsWith("[") || content.trim().startsWith("{")) {
                    restoreFromJson(content)
                } else {
                    restoreFromCsv(content)
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error restoring backup: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun restoreFromJson(jsonContent: String) {
        try {
            val jsonArray = JSONArray(jsonContent)
            val transactions = mutableListOf<Transaction>()

            for (i in 0 until jsonArray.length()) {
                val jsonObject = jsonArray.getJSONObject(i)
                val transaction = Transaction(
                    title = jsonObject.getString("title"),
                    amount = jsonObject.getDouble("amount"),
                    category = jsonObject.getString("category"),
                    date = jsonObject.getString("date"),
                    type = jsonObject.getString("type")
                )
                transactions.add(transaction)
            }

            // Replace all transactions
            replaceAllTransactions(transactions)

        } catch (e: Exception) {
            Toast.makeText(this, "Invalid JSON format: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun restoreFromCsv(csvContent: String) {
        try {
            val lines = csvContent.trim().split("\n")

            // Skip header row
            if (lines.size <= 1) {
                Toast.makeText(this, "CSV file is empty or invalid", Toast.LENGTH_SHORT).show()
                return
            }

            val transactions = mutableListOf<Transaction>()

            // Process from line 1 (skip header)
            for (i in 1 until lines.size) {
                val line = lines[i]

                // Parse CSV line properly
                val parts = parseCSVLine(line)
                if (parts.size >= 5) {
                    try {
                        val transaction = Transaction(
                            title = parts[0],
                            amount = parts[1].toDoubleOrNull() ?: 0.0,
                            category = parts[2],
                            date = parts[3],
                            type = parts[4]
                        )
                        transactions.add(transaction)
                    } catch (e: Exception) {
                        // Log error but continue with other transactions
                        e.printStackTrace()
                    }
                }
            }

            // Replace all transactions
            replaceAllTransactions(transactions)

        } catch (e: Exception) {
            Toast.makeText(this, "Error parsing CSV: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun parseCSVLine(line: String): List<String> {
        val result = mutableListOf<String>()
        var current = StringBuilder()
        var inQuotes = false

        for (c in line) {
            when {
                c == '"' && !inQuotes -> inQuotes = true
                c == '"' && inQuotes -> {
                    // Check for escaped quotes (two double quotes in a row)
                    if (line.getOrNull(line.indexOf(c) + 1) == '"') {
                        current.append('"')
                        // Skip the next quote
                        continue
                    } else {
                        inQuotes = false
                    }
                }
                c == ',' && !inQuotes -> {
                    result.add(current.toString())
                    current = StringBuilder()
                }
                else -> current.append(c)
            }
        }

        // Add the last field
        result.add(current.toString())
        return result
    }

    private fun replaceAllTransactions(transactions: List<Transaction>) {
        // Clear existing transactions
        TransactionManager.clearAllTransactions(this)

        // Add new transactions
        transactions.forEach { transaction ->
            TransactionManager.addTransaction(this, transaction)
        }

        Toast.makeText(this, "${transactions.size} transactions restored", Toast.LENGTH_SHORT).show()
    }

    companion object {
        // Add this method to the TransactionManager class if not already present
        fun TransactionManager.clearAllTransactions(context: Context) {
            val sharedPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            sharedPrefs.edit().remove(TRANSACTIONS_KEY).apply()
        }
    }
}